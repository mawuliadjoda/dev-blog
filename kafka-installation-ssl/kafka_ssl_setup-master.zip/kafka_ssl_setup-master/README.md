# kafka ssl setup


#### Kafka SSL : Setup with self signed certificate — Part 1
    https://medium.com/jinternals/kafka-ssl-setup-with-self-signed-certificate-part-1-c2679a57e16c
