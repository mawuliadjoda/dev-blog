# Kafka Rest Client

### Build Images:
```shell script
mvn clean install docker:build
```
